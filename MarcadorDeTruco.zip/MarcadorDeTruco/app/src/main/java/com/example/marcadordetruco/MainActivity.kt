package com.example.marcadordetruco
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private var pontosNos = 0
    private var pontosEles = 0
    private var vitoriasNos = 0
    private var vitoriasEles = 0
    lateinit var textViewNos: TextView
    lateinit var textViewEles: TextView
    lateinit var textViewVitoriasNos: TextView
    lateinit var textViewVitoriasEles: TextView
    lateinit var btnMaisNos: Button
    lateinit var btnMenosNos: Button
    lateinit var btnMaisEles: Button
    lateinit var btnMenosEles: Button
    lateinit var btnReset: Button
    lateinit var btnResetVitorias: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textViewNos = findViewById(R.id.textViewNos)
        textViewEles = findViewById(R.id.textViewEles)
        textViewVitoriasNos = findViewById(R.id.textViewVitoriasNos)
        textViewVitoriasEles = findViewById(R.id.textViewVitoriasEles)
        btnMaisNos = findViewById(R.id.btnMaisNos)
        btnMenosNos = findViewById(R.id.btnMenosNos)
        btnMaisEles = findViewById(R.id.btnMaisEles)
        btnMenosEles = findViewById(R.id.btnMenosEles)
        btnReset = findViewById(R.id.btnReset)
        btnResetVitorias = findViewById(R.id.btnResetVitorias)
        atualizarPontos()
        btnMaisNos.setOnClickListener {
            if (pontosNos < 12) {
                pontosNos++
                verificarFimDeJogo()
                atualizarPontos()
            }
        }
        btnMenosNos.setOnClickListener {
            if (pontosNos > 0) {
                pontosNos--
                atualizarPontos()
            }
        }
        btnMaisEles.setOnClickListener {
            if (pontosEles < 12) {
                pontosEles++
                verificarFimDeJogo()
                atualizarPontos()
            }
        }
        btnMenosEles.setOnClickListener {
            if (pontosEles > 0) {
                pontosEles--
                atualizarPontos()
            }
        }
        btnReset.setOnClickListener {
            zerarPontuacao()
        }
        btnResetVitorias.setOnClickListener {
            zerarVitorias()
        }
    }
    private fun atualizarPontos() {
        textViewNos.text = pontosNos.toString()
        textViewEles.text = pontosEles.toString()
        textViewVitoriasNos.text = "Vitórias: $vitoriasNos"
        textViewVitoriasEles.text = "Vitórias: $vitoriasEles"
    }
    private fun verificarFimDeJogo() {
        if (pontosNos == 12 || pontosEles == 12) {
            val vencedor = if (pontosNos == 12) "Nós" else "Eles"
            AlertDialog.Builder(this)
                .setTitle("Fim do jogo")
                .setMessage("$vencedor ganhou!")
                .setPositiveButton("OK") { _, _ ->
                    if (pontosNos == 12) {
                        vitoriasNos++
                    } else {
                        vitoriasEles++
                    }
                    zerarPontuacao()
                } .
                setCancelable(false)
                .show()
        }
    }
    private fun zerarPontuacao() {
        AlertDialog.Builder(this)
            .setTitle("Zerar")
            .setMessage("Tem certeza que deseja começar novamente a pontuação?")
            .setPositiveButton("OK") { _, _ ->
                pontosNos = 0
                pontosEles = 0
                atualizarPontos()
            } .
            setNegativeButton("Cancel", null)
            .show()
    }
    private fun zerarVitorias() {
        AlertDialog.Builder(this)
            .setTitle("Zerar Vitórias")
            .setMessage("Tem certeza que deseja zerar as vitórias?")
            .setPositiveButton("OK") { _, _ ->
                vitoriasNos = 0
                vitoriasEles = 0
                atualizarPontos()
            } .
            setNegativeButton("Cancel", null)
            .show()
    }
}