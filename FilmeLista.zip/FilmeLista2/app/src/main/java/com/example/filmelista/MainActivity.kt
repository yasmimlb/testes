package com.example.filmelista

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filmelista.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)


        val filmes = listOf(
            Filme("Matrix", "Ação/Ficção Científica", 1999),
            Filme("Shrek", "Animação/Comédia", 2001),
            Filme("Tropa de Elite", "Ação/Drama", 2007),
            Filme("O Auto da Compadecida", "Comédia/Aventura", 2000),
            Filme("Meu Malvado Favorito", "Animação/Infantil", 2010),
            Filme("Titanic", "Romance/Drama", 1997),
            Filme("O Poderoso Chefão", "Crime/Drama", 1972),
            Filme("Frozen", "Animação/Fantasia", 2013),
            Filme("Corra", "Terror", 2017),
            Filme("O Chamado", "Terror", 2002),
            Filme("Harry Potter e a Pedra Filosofal", "Fantasia/Aventura", 2001),
            Filme("A Culpa é das Estrelas", "Romance/Drama", 2014)
        )


        recyclerView.adapter = FilmeAdapter(filmes)
        recyclerView.layoutManager = GridLayoutManager(this, 2)
    }
}
