package com.example.filmelista

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FilmeAdapter(private val listaFilmes: List<Filme>) : RecyclerView.Adapter<FilmeAdapter.FilmeViewHolder>() {

    class FilmeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tituloTextView: TextView = itemView.findViewById(R.id.tituloTextView)
        val generoTextView: TextView = itemView.findViewById(R.id.generoTextView)
        val anoTextView: TextView = itemView.findViewById(R.id.anoTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_filme, parent, false)
        return FilmeViewHolder(view)
    }

    override fun onBindViewHolder(holder: FilmeViewHolder, position: Int) {
        val filme = listaFilmes[position]
        holder.tituloTextView.text = filme.titulo
        holder.generoTextView.text = filme.genero
        holder.anoTextView.text = filme.ano.toString()
    }

    override fun getItemCount() = listaFilmes.size
}
