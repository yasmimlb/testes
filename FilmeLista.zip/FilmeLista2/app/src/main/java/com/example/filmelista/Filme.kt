package com.example.filmelista

data class Filme(
    val titulo: String,
    val genero: String,
    val ano: Int
)
